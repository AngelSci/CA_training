import math

size = 1000000
def f(size):
    for i in range(1, size+1):
        r = math.log(i)

