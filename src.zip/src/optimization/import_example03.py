from math import log

size = 1000000
def f(size):
    for i in range(1, size+1):
        r = log(i)

