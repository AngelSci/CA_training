
size = 1000000
def f(size):
    from math import log
    for i in range(1,size+1):
        r = log(i)

