from qstats.utils import collect
from qstats.job import Job
