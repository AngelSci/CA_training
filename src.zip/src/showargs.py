import sys
for item,argument in enumerate(sys.argv):
    print('sys.argv[%d] is %s' % (item,argument))
