from hello import hello

hello('David')
