Material borrowed and adapted from https://github.com/ContinuumIO/anaconda_training_videos/tree/master/Conda

