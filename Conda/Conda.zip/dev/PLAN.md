# What you need

* www.anaconda.org to download packages for creating conda environments

# Lesson Files and Order

* `01_Conda_Introduction.ipynb`
* `02_Conda_Using_Environments.ipynb`
* `03_Conda_Managing_Environments.ipynb`
* `04_Conda_Sharing.ipynb`
* `05_Conda_Packages.ipynb`

